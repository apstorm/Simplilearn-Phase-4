package com.sportyShoes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SportyShoesECommerceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SportyShoesECommerceApplication.class, args);
	}

}

package com.sportyShoes.controller;

import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.sportyShoes.entity.PurchaseHistory;
import com.sportyShoes.entity.Users;
import com.sportyShoes.repository.PurchaseHistoryRepository;
import com.sportyShoes.repository.UserRepository;
import com.sportyShoes.service.UserService;

@Controller
@Transactional
public class AdminMainController {

	@Autowired
	private UserService userService;
	
	@Autowired
	private UserRepository userRepository;
	
	@GetMapping("/changeAdminPassword")
	public String changeAdminPassword()
	{
		return "changeAdminPassword";
	}
	
	@PostMapping("/changePassword")
	public String changePassword(
			@RequestParam Map<String, String> maps,
			RedirectAttributes ra
			)
	{
		
		String email=maps.get("email");
		String oldPassword=maps.get("userOldPassword");
		String userNewPassword=maps.get("userNewPassword");
		System.out.println(email);
		System.out.println(oldPassword);
		System.out.println(userNewPassword);
		
		
		Users user = userService.getUserByEmail(email);
		System.out.println(user);
		String userType = user.getUserType();
		System.out.println(userType);
		if(userType.equalsIgnoreCase("admin"))
		{
		Users admin = userService.verifyAdmin(userType);
		System.out.println(admin);
		String adminPassword = admin.getUserPassword();
		int id=admin.getId();
		System.out.println(adminPassword);
			if(adminPassword.equals(oldPassword))
			{
				if(!oldPassword.equals(userNewPassword))
				{
					admin.setUserPassword(userNewPassword);
					System.out.println(admin);
//					userService.updatePasswordById(userNewPassword, id);
//					ra.addFlashAttribute("message", "Admin Password changed successfully!!");
//					ra.addFlashAttribute("alertClass", "alert-success");
					return "redirect:/admin1";
				}
				else if(oldPassword.equals(userNewPassword))
				{
					ra.addFlashAttribute("message", "Updating Password failed!!, please try again");
				    ra.addFlashAttribute("alertClass", "alert-danger");
				    return "redirect:/changeAdminPassword";
				}
			}
			/*} else
		{*/
		ra.addFlashAttribute("message", "Updating Password failed!!, please try again");
	    ra.addFlashAttribute("alertClass", "alert-danger");
	    return "redirect:/changeAdminPassword";
		} else
		{
			ra.addFlashAttribute("message", "Sorry!!!,Only Admin password can be changed.");
		    ra.addFlashAttribute("alertClass", "alert-danger");
		    return "redirect:/changeAdminPassword";
		}
		
//		return "redirect:/changeAdminPassword";
		
	}
	
	@PostMapping("/searchUser")
	public String searchUserByName(Model m,@RequestParam("userName") String userName)
	{
		List<Users> user = userRepository.getUserByName(userName);
		m.addAttribute("user",user);
		return "searchedUser";
	}
	
}

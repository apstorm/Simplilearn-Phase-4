package com.sportyShoes.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.sportyShoes.entity.Product;
import com.sportyShoes.entity.Users;
import com.sportyShoes.repository.ProductRepository;
import com.sportyShoes.repository.UserRepository;

@Controller
public class AdminSignupController {

	@Autowired
	private ProductRepository productRepository;
	
	@Autowired
	private UserRepository userRepository;
	
	@GetMapping("/admin1")
	public String adminSignup(Model m,RedirectAttributes ra)
	{
//		m.addAttribute("product",new Product());
		
		Users user = (Users) m.getAttribute("username");
		if(user!=null)
		{
			
			int userCount = userRepository.userCount();
			m.addAttribute("userCount", userCount);
			
			int productCount = productRepository.productCount();
			m.addAttribute("count",productCount);
			return "redirect:/admin";
			
		} 
		
		ra.addFlashAttribute("message", "Admin Password changed successfully!!");
		ra.addFlashAttribute("alertClass", "alert-success");
		return "redirect:/admin";
		
	}
	
	@GetMapping("/admin")
	public String adminSignup()
	{
		return "admin";
	}
	
}

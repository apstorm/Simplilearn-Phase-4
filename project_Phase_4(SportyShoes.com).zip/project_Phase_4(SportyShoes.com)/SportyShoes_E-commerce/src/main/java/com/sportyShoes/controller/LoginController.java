package com.sportyShoes.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.sportyShoes.entity.Users;
import com.sportyShoes.service.UserService;

@Controller
public class LoginController {

	@Autowired
	private UserService userService;
	
	@GetMapping("/login")
	public String loginHandler(Model m)
	{
		m.addAttribute("user",new Users());
		return "login";
	}
	
	@PostMapping("/loginProcess")
	public String loginProcessHandler(
			@Valid @ModelAttribute("user") Users users,
			Model m,
			HttpServletRequest req,
			RedirectAttributes ra,
			BindingResult res)
	{
		ra.addFlashAttribute("message", "Login failed!!, please try again or signup first");
	    ra.addFlashAttribute("alertClass", "alert-danger");
		
		List<Users> userList=this.userService.getAllUsers();
		if(res.hasErrors())
		{
			System.out.println(res);
			return "redirect:/login";
		}

		String email=users.getEmail();
		String password=users.getUserPassword();
		Users user=null;
		for(Users u:userList)
		{
			if(u.getEmail().equals(email) && 
					u.getUserPassword().equals(password))
			{
				user = this.userService.getUserByEmailAndPassword(email, password);
			}
		}
//		users=user;
		if(user!=null)
		{
			System.out.println(user);
			String username=user.getUserName();
			req.getSession().setAttribute("username", username);
			m.addAttribute("user",user);
			
			if(user.getUserType().equals("admin"))
			{
			
			ra.addFlashAttribute("message", "User Logged in successfully!!");
			ra.addFlashAttribute("alertClass", "alert-success");
			return "redirect:/admin";
			} 
			else if(user.getUserType().equals("normal")) {
			ra.addFlashAttribute("message", "User Logged in successfully!!");
			ra.addFlashAttribute("alertClass", "alert-success");
			return "redirect:/home1";
			}
//			else if(!users.getUserType().equals("admin")
//					&& !users.getUserType().equals("normal")){
//				System.out.println(user);			
//				ra.addFlashAttribute("message", "Login failed!!, please try again or signup first");
//			    ra.addFlashAttribute("alertClass", "alert-danger");
//				return "redirect:/userNotFound";
//				
//			} 
			
		} 
		System.out.println(user);			
		ra.addFlashAttribute("message", "Login failed!!, please try again or signup first");
	    ra.addFlashAttribute("alertClass", "alert-danger");
		return "redirect:/userNotFound";
	}
	
	@GetMapping("/userNotFound")
	public String userNotFound()
	{
		return "userNotFound";
	}
	
	@GetMapping("/logoutUser")
	public String logoutUser(RedirectAttributes ra)
	{
		ra.addFlashAttribute("message", "User Logged out successfully!!");
		ra.addFlashAttribute("alertClass", "alert-success");
		return "redirect:/logout";
	}
	
	@GetMapping("/logout")
	public String logoutController(HttpServletRequest req)
	{
		req.getSession().removeAttribute("username");
		return "logout";
	}
	
}

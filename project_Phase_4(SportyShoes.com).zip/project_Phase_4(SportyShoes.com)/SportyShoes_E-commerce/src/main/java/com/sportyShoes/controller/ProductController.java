package com.sportyShoes.controller;

import java.io.IOException;
import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.sportyShoes.entity.Product;
import com.sportyShoes.helper.FileUploadHelper;
import com.sportyShoes.repository.ProductRepository;
import com.sportyShoes.repository.UserRepository;
import com.sportyShoes.service.ProductService;

//@MultipartConfig
@Controller
public class ProductController {
	
	@Autowired
	private ProductService productService;
	
	@Autowired
	private ProductRepository productRepository;
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private FileUploadHelper fileUploadHelper;
	
	
	public final String UPLOAD_DIR=new ClassPathResource("static/image").getFile().getAbsolutePath();

	public ProductController() throws IOException
	{
		
	}
	
	@GetMapping("/getProducts")
	public String getProducts(Model model)
	{
		List<Product> products=this.productService.getAllProducts();
		model.addAttribute("products",products);
		return "admin";
	}
	
	
//	 @RequestMapping(value = { "/addProduct" }, method = RequestMethod.POST, consumes = {"multipart/form-data"})
	@PostMapping("/addProduct")
	public String addProduct(@ModelAttribute Product p,
//					@RequestParam("file") MultipartFile file,
//					@RequestParam("") String pName,
//					@RequestParam("") String pCategory,
//					@RequestParam("") long pPrice,
					RedirectAttributes ra) throws IOException, ServletException
	{
		
		try {
			
//			if(file.isEmpty())
//			{
//				ra.addFlashAttribute("message", "no picture is chosen !! please chose a file to upload");
//				ra.addFlashAttribute("alertClass", "alert-danger");
//				return "redirect:/admin";
//			}
			
			String category=p.getCategory();
			String name=p.getProductName();
			int price=p.getProductPrice();
			
//			Product addProduct = this.productService.addProduct(p,file, name, category, price);
			boolean addProduct = this.productService.addProduct(p);
			if(addProduct)
			{
				ra.addFlashAttribute("message", "product added successfully!!");
				ra.addFlashAttribute("alertClass", "alert-success");
			} else
			{
				ra.addFlashAttribute("message", "error!!,failed to add product!! please check");
				ra.addFlashAttribute("alertClass", "alert-danger");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		return "redirect:/admin";
	}
	
	@GetMapping("/delProduct")
	public String delProduct(@ModelAttribute Product p,
			RedirectAttributes ra)
	{
		int id = p.getId();
		boolean delProduct = this.productService.delProduct(id);
		
		if(delProduct)
		{
			ra.addFlashAttribute("message", "product deleted successfully!!");
			ra.addFlashAttribute("alertClass", "alert-success");
			return "redirect:/admin";
		}
		
		ra.addFlashAttribute("message", "Error !!,failed to delete product, please check again");
		ra.addFlashAttribute("alertClass", "alert-danger");
		return "redirect:/admin";
	}
	
	@GetMapping("/update")
	public String updateProduct(@ModelAttribute Product p,
							Model model,
							RedirectAttributes ra)
	{
		
		int id = p.getId();
//		String category = p.getCategory();
//		String productName = p.getProductName();
//		BigInteger productPrice = p.getProductPrice();
		boolean updateProduct = this.productService.updateProduct(p,id);
		
		if(updateProduct)
		{
			List<Product> allProducts = productRepository.getAllProducts();
			model.addAttribute("products",allProducts);
			ra.addFlashAttribute("message", "product updated successfully!!");
			ra.addFlashAttribute("alertClass", "alert-success");
			return "redirect:/admin";
		}
		
		ra.addFlashAttribute("message", "Error !!,failed to product product, please check again");
		ra.addFlashAttribute("alertClass", "alert-danger");
		return "redirect:/admin";
	}
	
	@GetMapping("/allProducts")
	public String allProducts(Model m)
	{
		List<Product> allProducts = productRepository.getAllProducts();
		
		m.addAttribute("allProducts", allProducts);
		return "allProducts";
	}
	
}

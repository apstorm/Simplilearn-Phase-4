package com.sportyShoes.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.sportyShoes.entity.PurchaseHistory;
import com.sportyShoes.repository.PurchaseHistoryRepository;

@Controller
public class PurchaseHistoryController {

	@Autowired
	private PurchaseHistoryRepository purchaseHistoryRepository;
	
	@GetMapping("/purchaseHistory")
	public String purchaseHistory(Model m)
	{
		List<PurchaseHistory> purchaseHistory = purchaseHistoryRepository.getPurchaseHistory();
	
		m.addAttribute("purchaseHistory", purchaseHistory);
		return "purchaseHistory";
	}
	
}

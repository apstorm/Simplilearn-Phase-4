package com.sportyShoes.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.sportyShoes.entity.Cart;
import com.sportyShoes.entity.Product;
import com.sportyShoes.entity.Users;
import com.sportyShoes.repository.CartRepository;
import com.sportyShoes.repository.ProductRepository;
import com.sportyShoes.repository.UserRepository;
import com.sportyShoes.service.ProductService;

@Transactional
@Controller
public class UserController {
	
	@Autowired
	private ProductRepository productRepository;
	
	@Autowired
	private ProductService productService;
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private CartRepository cartRepository;
	
	@GetMapping({"/","/home1"})
	public String showhome(Model m,RedirectAttributes ra)
	{
		Users user = (Users) m.getAttribute("users");
		if(user==null)
		{
			ra.addFlashAttribute("message", "User not Logged in!!, login first or signup");
			ra.addFlashAttribute("alertClass", "alert-success");
			return "redirect:/login";
		} 
		List<Product> allProducts = productRepository.getAllProducts();
		m.addAttribute("products",allProducts);
		return "redirect:/home";
			
	}
	
	@GetMapping({"/home"})
	public String showHome(Model m)
	{
		Users user = (Users) m.getAttribute("users");
		if(user==null)
		{
			return "redirect:/login";
		} 
		
		List<Product> allProducts = productRepository.getAllProducts();
		m.addAttribute("products",allProducts);
		return "home";
	}
	
//	@GetMapping("/addToCart/{id}")
//	public String addToCart(@PathVariable("id") int id,
//			HttpServletRequest req)
//	{
//		try {
//			int totaPprice=0;
//			int quantity=0;
//			int cart_totat=0;
//			int z=0;
//			String username = (String) req.getAttribute("username");
//			
//			System.out.println();
//			Product product = this.productService.getProductById(id);
//			int productPrice = product.getProductPrice();
//			totaPprice=productPrice;
//			
//			//to check whether product exist or not
//			List<Cart> cart = cartRepository.getByIdAnduserName(id,username);
//			for(Cart c:cart)
//			{
//				cart_totat= c.getTotalCost();
//				cart_totat=cart_totat+totaPprice;
//				quantity=c.getQuantity();
//				quantity=quantity+1;
//				z=1;
//			}
//			if(z==1)
//			{
//				cartRepository.updateCartSetTotalAndQuantityWhereIdAndUserName(
//									productPrice,
//									quantity, 
//									id, 
//									username);
//				
//			}
//			
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		return "addToCart";
//	}
	
	
	@GetMapping("/allUsers")
	public String allUsers(Model m)
	{
		List<Users> allUsers = userRepository.getAllUsers();
		m.addAttribute("allUsers",allUsers);
		return "allUsers";
	}
}

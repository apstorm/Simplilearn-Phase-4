package com.sportyShoes.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.sportyShoes.entity.Users;
import com.sportyShoes.service.UserService;

@Controller
public class UserSignupController {
	@Autowired
	private UserService userService;
	
	@GetMapping("/signup")
	public String signupHandler(Model m,RedirectAttributes redirectAttributes)
	{
		m.addAttribute("user",new Users());
		redirectAttributes.addFlashAttribute("message", "Error in Registering User!!, please try again");
	    redirectAttributes.addFlashAttribute("alertClass", "alert-danger");
		return "signup";
	}
	
	@PostMapping("/process")
	public String processHandler(@Valid @ModelAttribute("user") Users user, 
			RedirectAttributes redirectAttributes,
			BindingResult res)
	{
		 	redirectAttributes.addFlashAttribute("message", "Error in Registering User!!, please try again");
		    redirectAttributes.addFlashAttribute("alertClass", "alert-danger");
		if (res.hasErrors()) {
			System.out.println(res);
			
			return "redirect:/signup";
		}
		Users users=null;
		try {
			users=this.userService.addUser(user);
			
			System.out.println(users);
			redirectAttributes.addFlashAttribute("message", "User Registered successfully!!");
			redirectAttributes.addFlashAttribute("alertClass", "alert-success");
			return "redirect:/signup";
		} catch (Exception e) {
			e.printStackTrace();
		}
				
		return "redirect:/signup";
	}
	
}

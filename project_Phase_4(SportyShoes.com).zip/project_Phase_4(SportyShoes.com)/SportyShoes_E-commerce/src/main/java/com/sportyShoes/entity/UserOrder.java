package com.sportyShoes.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "user_orders")
public class UserOrder {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "order_id", updatable = true, nullable = false)
	private int id;
	
	private int total;
	
	@OneToOne(cascade = CascadeType.ALL,mappedBy = "userOrder")
	private Users users;
	
	private Date date;
	
	@ManyToMany(mappedBy = "userOrders",fetch = FetchType.EAGER)
	private List<Product> products=new ArrayList<>();
	
	public void addProducts(Product product) {
		this.products.add(product);
	}

	public void delProducts(Product product) {
		this.products.remove(product);
	}

}

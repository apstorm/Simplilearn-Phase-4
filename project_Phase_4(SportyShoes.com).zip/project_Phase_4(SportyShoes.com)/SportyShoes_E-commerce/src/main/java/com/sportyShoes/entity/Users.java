package com.sportyShoes.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import org.springframework.beans.factory.annotation.Value;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="users")
public class Users {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "user_id",updatable = true,nullable = false)
	private int id;
	
//	@NotBlank(message = "User name can't be left empty")
	@Size(min = 3, max = 15, message = "username must be between 3 to 15 characters")
	@Column(name = "user_name")
	private String userName;
	
	@Email(regexp = "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$",message = "invalid email !!")
	@Column(name = "user_email")
	private String email;
	
	@NotBlank(message = "User Password can't be left empty")
	@Size(min = 3, max = 15, message = "password must be between 3 to 15 characters")
	@Column(name = "user_password")
	private String userPassword;
	
	@Column(name = "user_type")
//	@Value("${user.type}")
	private String userType="normal";
	
	@OneToOne(cascade = CascadeType.ALL)
	private UserOrder userOrder;
	
//	public Users() {
//		
//	}
//
//	public Users(String userName, String email, String userPassword,String userType) {
//		super();
//		this.userName = userName;
//		this.email = email;
//		this.userPassword = userPassword;
//		this.userType=userType;
//	}
//
//	public int getId() {
//		return id;
//	}
//
//	public void setId(int id) {
//		this.id = id;
//	}
//
//	public String getUserName() {
//		return userName;
//	}
//
//	public void setUserName(String userName) {
//		this.userName = userName;
//	}
//
//	public String getEmail() {
//		return email;
//	}
//
//	public void setEmail(String email) {
//		this.email = email;
//	}
//
//	public String getUserPassword() {
//		return userPassword;
//	}
//
//	public void setUserPassword(String userPassword) {
//		this.userPassword = userPassword;
//	}
//	
//	public String getUserType() {
//		return userType;
//	}
//
//	public void setUserType(String userType) {
//		this.userType = userType;
//	}
//
//	@Override
//	public String toString() {
//		return "Users [userName=" + userName + ", email=" + email + ", userPassword=" + userPassword + ", userType="
//				+ userType + "]";
//	}

}

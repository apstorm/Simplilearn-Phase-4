package com.sportyShoes.helper;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.sportyShoes.entity.Product;
import com.sportyShoes.repository.ProductRepository;

@Component
public class FileUploadHelper {
	
	@Autowired
	private ProductRepository productRepository;

	public final String UPLOAD_DIR=
			new ClassPathResource("static/image").getFile().getAbsolutePath();

	public FileUploadHelper() throws IOException
	{
		
	}
	
	public boolean uploadFile(MultipartFile file,Product product)
	{
		boolean f=false;
//		String fileName=file.getOriginalFilename();
		
		if(!file.isEmpty())
		{	
			try {
				String fileName=file.getOriginalFilename();
				Product p=new Product();
				p.setCategory(p.getCategory());
				
				
				Files.copy(
						file.getInputStream(),
						Paths.get(UPLOAD_DIR+File.separator+
								file.getOriginalFilename()),
						StandardCopyOption.REPLACE_EXISTING);
				f=true;
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		
		return f;
	}
	
}

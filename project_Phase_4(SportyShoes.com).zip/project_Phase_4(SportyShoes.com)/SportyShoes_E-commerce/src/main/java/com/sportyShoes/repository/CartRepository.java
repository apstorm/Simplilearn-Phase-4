package com.sportyShoes.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sportyShoes.entity.Cart;

@Transactional
@Repository
public interface CartRepository extends JpaRepository<Cart, Integer>{

	@Query("select c from Cart c where c.cid=:id and c.userName=:userName")
	public List<Cart> getByIdAnduserName(@Param("id") int id,@Param("userName") String userName);
	
	@Query("update Cart c set c.totalCost=:totalCost,c.quantity=:quantity "
			+ "where c.cid=:cid and c.userName=:userName")
	public void updateCartSetTotalAndQuantityWhereIdAndUserName(
					@Param("totalCost") int totalCost,
					@Param("quantity") int quantity,
					@Param("cid") int cid,
					@Param("userName") String userName);
	
}

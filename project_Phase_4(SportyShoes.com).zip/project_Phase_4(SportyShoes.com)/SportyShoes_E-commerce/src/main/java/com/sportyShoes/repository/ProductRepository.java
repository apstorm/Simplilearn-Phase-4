package com.sportyShoes.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sportyShoes.entity.Product;

@Transactional
@Repository
public interface ProductRepository extends JpaRepository<Product, Integer>{

	@Query("select p from Product p")
	public List<Product> getAllProducts();

	@Query("select p from Product p where p.id =:id ")
	public Product getById(@Param("id") int id);
	
	@Query("select count(p) from Product p")
	public int productCount();
	
	@Query(value = "select uo,p from user_orders uo JOIN uo.products p order by p.product_category desc ",nativeQuery = true)
	public List<Object[]> testPurchaseRepoQuery();
	
}

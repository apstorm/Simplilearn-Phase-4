package com.sportyShoes.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.sportyShoes.entity.PurchaseHistory;

@Repository
public interface PurchaseHistoryRepository extends JpaRepository<PurchaseHistory, Integer> {

	@Query(value ="select * from order_purchase_history order by category and date desc;",nativeQuery = true)
	public List<PurchaseHistory> getPurchaseHistory();
	
	@Query(value = "SELECT * FROM order_purchase_history"
				+ " order by category and date desc",nativeQuery = true)
	public List<PurchaseHistory> getPurchaseHistoryOrderByCategoryAndDate();
}

package com.sportyShoes.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sportyShoes.entity.UserOrder;
import com.sportyShoes.entity.Users;

@Repository
//@Transactional
public interface UserRepository extends JpaRepository<Users, Integer> {
	@Query("select u from Users u")
	public List<Users> getAllUsers();
	
	@Query("select u from Users u where u.email =:e and u.userPassword =:ps")
	public Users getUserByEmailAndPassword(
			@Param("e") String email,
			@Param("ps") String password);
	
	@Query("select u from Users u where u.id =:id")
	public Users getUserById(@Param("id") int id);
	
	@Query("select u from Users u where u.email =:email")
	public Users getUserByEmail(@Param("email") String email);
	
	@Query("select count(u) from Users u")
	public int userCount();
	
	@Query("select u from Users u where u.userName=:name")
	public List<Users> getUserByName(@Param("name") String name);
	
//	admin queries

	//DML not allowed
//	@Query("update Users u set u.userPassword =:password where u.id =:id")
//	public Users updatePasswordById(@Param("password") String password,@Param("id") int id);
	
	@Query("select u from Users u where u.userType =:userType")
	public Users verifyAdmin(@Param("userType") String userType);
	
}

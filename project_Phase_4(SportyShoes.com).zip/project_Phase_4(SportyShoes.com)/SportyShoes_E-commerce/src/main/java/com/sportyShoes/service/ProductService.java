package com.sportyShoes.service;

import java.io.IOException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sportyShoes.entity.Product;
import com.sportyShoes.entity.UserOrder;
import com.sportyShoes.repository.ProductRepository;
import com.sportyShoes.repository.UserOrderRepository;

@Transactional
@Service
public class ProductService {

	@Autowired
	private EntityManager entityManager;
	
	@Autowired
	private ProductRepository productRepository;
	
	@Autowired
	private UserOrderRepository userOrderRepository;
	
	@Autowired
	private UserOrderService userOrderService;
	
	public List<Product> getAllProducts()
	{
		List<Product> allProducts = productRepository.getAllProducts();
		return allProducts;
	}
	
	public Product getProductById(int id)
	{
		Product p = productRepository.getById(id);
		return p;
	}
	
//	public Product addProduct(Product p,
//						MultipartFile file,
//						String pName,
//						String pCategory,
//						int pPrice) throws IOException
//	{
//		
//		String image=StringUtils.cleanPath(file.getOriginalFilename());
//		if(image.contains(".."))
//		{
//			System.out.println("not a valid file");
//		}
//		p.setCategory(pCategory);
//		p.setProductName(pName);
//		p.setProductPrice(pPrice);
//		p.setPPhoto(Base64.getEncoder().encodeToString(file.getBytes()));		
//		productRepository.save(p);
//		return p;
//	}
	
	public boolean addProduct(Product p) throws IOException
{
		boolean f=false;
		Product save = productRepository.save(p);
		if(save != null)
		{
			f=true;
		}
		
		return f;
}
	
	public boolean delProduct(int id)
	{
		boolean f=false;
		Product byId = productRepository.getById(id);
		if(byId !=null)
		{
		productRepository.delete(byId);
		f=true;
		}
		return f;
	}
	
	public boolean updateProduct(Product p,int id)
	{
		boolean f=false;
		
		Product byId = getProductById(id);
		if(byId !=null)
		{
			
			byId.setCategory(p.getCategory());
			byId.setProductName(p.getProductName());
			byId.setProductPrice(p.getProductPrice());
			
		Product save = productRepository.save(byId);
		f=true;
		}
		return f;
	}
	
	public Product searchProduct(int id)
	{
		Product p=productRepository.getById(id);
		return p;
	}
	
	public UserOrder addProductToOrder(int orderId, int productId)
	{
		UserOrder userOrder=userOrderRepository.getOrderById(orderId);
		Product product = productRepository.getById(productId);
		userOrder.addProducts(product);
		product.addUserOrders(userOrder);
		userOrderRepository.save(userOrder);
		return userOrder;
		
	}
	
	public UserOrder addProductToUserOrder(int productId,int userId)
	{
		UserOrder userOrder=userOrderService.createNewOrder(userId);
		int orderId=userOrder.getId();
		UserOrder order=addProductToOrder(orderId, productId);
		return order;
	}
	
	public List<Object[]> testPurchaseRepoQuery()
	{
		List<Object[]> resList = userOrderRepository.testPurchaseRepoQuery();
		return resList;
	}
}

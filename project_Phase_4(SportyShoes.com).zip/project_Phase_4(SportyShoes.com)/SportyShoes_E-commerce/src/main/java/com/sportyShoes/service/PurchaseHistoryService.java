package com.sportyShoes.service;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sportyShoes.entity.Product;
import com.sportyShoes.entity.PurchaseHistory;
import com.sportyShoes.entity.UserOrder;
import com.sportyShoes.repository.ProductRepository;
import com.sportyShoes.repository.PurchaseHistoryRepository;

@Transactional
@Service
public class PurchaseHistoryService {

	@Autowired
	private ProductRepository productRepository;
	
	@Autowired
	private PurchaseHistoryRepository purchaseHistoryRepository;
	
	@Autowired
	private EntityManager em;
	
	public void save(PurchaseHistory purchaseHistory)
	{
		purchaseHistoryRepository.save(purchaseHistory);
	}
	
	public void addDataToPurchaseHistory()
	{
		List<Object[]> rsList=productRepository.testPurchaseRepoQuery();
		
		for(Object[] res:rsList)
		{
			Product p=(Product) res[1];
			UserOrder userOrder=(UserOrder) res[0];
			int productId=p.getId();
			int orderId=userOrder.getId();
			int cost=p.getProductPrice();
			int total=userOrder.getTotal();
			int userId=userOrder.getUsers().getId();
			String category=p.getCategory();
			String productName=p.getProductName();
			Date date=userOrder.getDate();
			PurchaseHistory ph=new PurchaseHistory();
			ph.setProductId(productId);
			ph.setOrderId(orderId);
			ph.setPrce(cost);
			ph.setTotal(total);
			ph.setUserId(userId);
			ph.setCategory(category);
			ph.setProductName(productName);
			ph.setDate(date);
			save(ph);
		}
	}

	public List<PurchaseHistory> getPurchaseHistory()
	{
		addDataToPurchaseHistory();
		List<PurchaseHistory> purchaseHistory = purchaseHistoryRepository.getPurchaseHistoryOrderByCategoryAndDate();
		return purchaseHistory;
	}
	
}

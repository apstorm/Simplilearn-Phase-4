package com.sportyShoes.service;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sportyShoes.entity.Product;
import com.sportyShoes.entity.UserOrder;
import com.sportyShoes.entity.Users;
import com.sportyShoes.repository.UserOrderRepository;
import com.sportyShoes.repository.UserRepository;

@Transactional
@Service
public class UserOrderService {

	@Autowired
	private UserOrderRepository userOrderRepository;
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private EntityManager entityManager;
	
	public UserOrder insert()
	{
		UserOrder userOrder=new UserOrder();		
		Product product=new Product();
		
		
		userOrder.setDate(new Date());
		product.setProductName("woodland shoe");
		entityManager.persist(product);
		entityManager.persist(userOrder);
		
		userOrder.addProducts(product);
		product.addUserOrders(userOrder);
		entityManager.persist(userOrder);
		return userOrder;
	}
	
	public int TotalCost(int orderId) {
		UserOrder userOrder=entityManager.find(UserOrder.class, orderId);
		List<Product> products=userOrder.getProducts();
		int sum=0;
		
		for(int i=0;i< products.size();i++)
		{
			sum+=products.get(i).getProductPrice();
		}
		return sum;
	}
	
	public int addTotalCostToOrder(int orderId)
	{
		int sum=TotalCost(orderId);
		UserOrder userOrder=entityManager.find(UserOrder.class, orderId);
		userOrder.setTotal(sum);
		entityManager.persist(userOrder);
		entityManager.flush();
		return userOrder.getTotal();
		
	}
	
	public List<UserOrder> getAllOrders()
	{
		List<UserOrder> allOrders = userOrderRepository.getAllOrders();
		return allOrders;
	}
	
	public UserOrder createNewOrder(int id)
	{
		Users users=userRepository.getUserById(id);
		UserOrder userOrder=users.getUserOrder();
		if(userOrder==null)
		{
			userOrder=new UserOrder();
			userOrder.setDate(new Date());
			userOrder.setId(id);
			entityManager.persist(userOrder);
			userService.addUserOrder(id, userOrder);
			entityManager.persist(userOrder);
			return userOrder;
		} else
		{
			return userOrder;
		}
		
	}
	
	public UserOrder getOrder(int orderId)
	{
		UserOrder userOrder=userOrderRepository.getOrderById(orderId);
		return userOrder;
	}
	
}

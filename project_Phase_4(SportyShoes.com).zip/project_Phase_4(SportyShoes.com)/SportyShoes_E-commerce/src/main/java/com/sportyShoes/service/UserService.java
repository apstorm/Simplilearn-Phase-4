package com.sportyShoes.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sportyShoes.entity.UserOrder;
import com.sportyShoes.entity.Users;
import com.sportyShoes.repository.UserRepository;

@Service
public class UserService {
	@Autowired
	private UserRepository userRepository;
	
	// adding a user
	public Users addUser(Users u)
	{
		Users us=userRepository.save(u);
		return u;
	}
	
	// get all users
	public List<Users> getAllUsers()
	{
		List<Users> allUsers = userRepository.getAllUsers();
		return allUsers;
	}
	
	// get user by email and password
	public Users getUserByEmailAndPassword(String email, String password)
	{
		Users users = userRepository.getUserByEmailAndPassword(email, password);
		return users;
	}
	
	// get user by email
	public Users getUserByEmail(String email)
	{
		Users users = userRepository.getUserByEmail(email);
		return users;
	}
	
//	admin functions
	public Users verifyAdmin(String userType)
	{
		Users admin = userRepository.verifyAdmin(userType);
		return admin;
	}
//	_________________________________________
	public void addUserOrder(int id, UserOrder userOrder)
	{
		Users user = userRepository.getUserById(id);
		user.setUserOrder(userOrder);
		Users save = userRepository.save(user);
	}
	
	public List<Users> searchUserByName(String name)
	{
		List<Users> user = userRepository.getUserByName(name);
		return user;
	}
	
	public void addUserOrderToUser(int id, UserOrder order)
	{
		Users u=userRepository.getUserById(id);
		u.setUserOrder(order);
		userRepository.save(u);
	}
	
	public UserOrder verifyUserToOrder(int userId)
	{
		Users users=userRepository.getUserById(userId);
		return users.getUserOrder();
	}
	
	//DML not allowed
//	public Users updatePasswordById(String password, int id)
//	{
//		Users users1 = userRepository.updatePasswordById(password, id);
//		return users1;
//	}
	
//	public Users updatePasswordByEmailAndOldPasswordAndNewPassword(
//			String email, String oldPassword, String newUserPassword)
//	{
//		Users user = null;
//		return user;
//	}
	
}

package com.sportyShoes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SportyShoesECommerceApplicationTests {

	@Test
	void contextLoads() {
	}

}
